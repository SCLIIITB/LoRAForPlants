from torchvision import models
import torchvision
import torch

def model_config(model_name='mobilenetv3_large'):
    model = {
        #'mobilenetv3_large': models.mobilenet_v3_large(weights='DEFAULT'),
        #'shufflenetv2_x1_5': models.shufflenet_v2_x1_5(weights='DEFAULT'),
        #'efficientnetb0': models.efficientnet_b0(weights='DEFAULT'),
        'resnet50':torchvision.models.resnet50()
    }
    return model[model_name]

def build_model(model_name='mobilenetv3_large', fine_tune="partial", num_classes=10, custom_wt_path=None):
    model = model_config(model_name)
    if fine_tune=="True":
        print('[INFO]: Fine-tuning all layers...')
        for params in model.parameters():
            params.requires_grad = True
    elif fine_tune == "False":
        print('[INFO]: Freezing hidden layers...')
        for params in model.parameters():
            params.requires_grad = False
    elif fine_tune == "partial":
        print('[INFO]: Freezing partial hidden layers...')
        modules_to_unfreeze = ["layer4"]

        for param in model.parameters():
            param.requires_grad = False
        # Unfreeze the specified modules
        for name, module in model.named_children():
            if name in modules_to_unfreeze:
                for param in module.parameters():
                    param.requires_grad = True

    if model_name == 'resnet50':
        model.fc.out_features = num_classes
    if  model_name == 'mobilenetv3_large':
        model.classifier[3].out_features = num_classes
    if model_name == 'shufflenetv2_x1_5':
        model.fc.out_features = num_classes
    if model_name == 'mobilenetv3_large':
        model.classifier[1].out_features = num_classes
    if custom_wt_path!=None:
        #model.load_state_dict(torch.load(custom_wt_path))
        checkpoint = torch.load(custom_wt_path)
        model.load_state_dict(checkpoint['model_state_dict'])
        #optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        epoch = checkpoint['epoch']
    return model