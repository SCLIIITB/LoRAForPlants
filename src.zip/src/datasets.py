import os
import torch
from PIL import Image
from torchvision import datasets, transforms
from torch.utils.data import DataLoader, Subset, Dataset
import pandas as pd
import numpy as np
# Required constants.
ROOT_DIR = os.path.join('..', 'input','pvd')
ROOT_DIR_FIELD = os.path.join('..', 'input','train')
IMAGE_SIZE = 224 # Image size of resize when applying transforms.
BATCH_SIZE = 32
NUM_WORKERS = 4 # Number of parallel processes for data preparation.
VALID_SPLIT = 0.15 # Ratio of data for validation

# Training transforms

class CustomDataset(Dataset):
    def __init__(self, csv_file, root_dir, transform=None):
        self.data = pd.read_csv(csv_file)
        self.root_dir = root_dir
        self.transform = transform
        self.classes = self.data.columns[1:]

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        img_name = os.path.join(self.root_dir, self.data.iloc[idx, 0])
        image = Image.open(img_name).convert("RGB")

        labels = np.argmax(self.data.iloc[idx, 1:].values.astype(float))#torch.argmax(torch.tensor(self.data.iloc[idx, 1:].values, dtype=torch.float32))

        if self.transform:
            image = self.transform(image)

        return image, labels

def get_train_transform(image_size):
    train_transform = transforms.Compose([
        transforms.Resize((image_size, image_size)),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.RandomVerticalFlip(p=0.5),
        transforms.RandomRotation(35),
        transforms.ColorJitter(brightness=0.4,
                               contrast=0.4,
                               saturation=0.4,
                               hue=0),
        transforms.GaussianBlur(kernel_size=3, sigma=(0.5, 1.5)),
        transforms.RandomAdjustSharpness(sharpness_factor=2, p=0.5),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
            )
    ])
    return train_transform

# Validation transforms
def get_valid_transform(image_size):
    valid_transform = transforms.Compose([
        transforms.Resize((image_size, image_size)),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
            )
    ])
    return valid_transform

def get_datasets(fromCsv=False):
    """
    Function to prepare the Datasets.
    Returns the training and validation datasets along 
    with the class names.
    """
    if fromCsv:
        # Example usage
        csv_file_path = ROOT_DIR_FIELD + "/_classes.csv"
        image_root_dir = ROOT_DIR_FIELD
        
        transform = transforms.Compose([
        transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
            )
        ])

        dataset = CustomDataset(csv_file=csv_file_path, root_dir=image_root_dir, transform=transform)
        # dataloader = DataLoader(dataset, batch_size=32, shuffle=True)
    else:
        dataset = datasets.ImageFolder(
            ROOT_DIR, 
            transform=(get_train_transform(IMAGE_SIZE))
        )
        dataset_test = datasets.ImageFolder(
            ROOT_DIR, 
            transform=(get_valid_transform(IMAGE_SIZE))
        )
    dataset_size = len(dataset)

    # Calculate the validation dataset size.
    valid_size = int(VALID_SPLIT*dataset_size)
    # Radomize the data indices.
    indices = torch.randperm(len(dataset)).tolist()
    # Training and validation sets.
    dataset_train = Subset(dataset, indices[:-valid_size])
    dataset_valid = Subset(dataset, indices[-valid_size:])

    return dataset_train, dataset_valid, dataset.classes

def get_data_loaders(dataset_train, dataset_valid):
    """
    Prepares the training and validation data loaders.
    :param dataset_train: The training dataset.
    :param dataset_valid: The validation dataset.
    Returns the training and validation data loaders.
    """
    train_loader = DataLoader(
        dataset_train, batch_size=BATCH_SIZE, 
        shuffle=True, num_workers=NUM_WORKERS
    )
    valid_loader = DataLoader(
        dataset_valid, batch_size=BATCH_SIZE, 
        shuffle=False, num_workers=NUM_WORKERS
    )
    return train_loader, valid_loader 